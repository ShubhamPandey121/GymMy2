'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { FitnessIcon} from '@/components/icons/FitnessIcons';
import { Goal } from '@/types/fitness';

export default function HomePage() {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [showNewGoalModal, setShowNewGoalModal] = useState(false);
  const [newGoal, setNewGoal] = useState({
    title: '',
    type: 'weight-loss' as Goal['type'],
    targetValue: '',
    unit: 'kg',
    deadline: '',
  });
  const [currentQuote, setCurrentQuote] = useState('');
  const [userData, setUserData] = useState<any>(null);
  const router = useRouter();

  const motivationalQuotes = [
    "The only bad workout is the one that didn't happen. Let's make today count! 💪",
    "Your body can do it. It's your mind you have to convince! 🧠",
    "Success is the sum of small efforts repeated day in and day out! 🌟",
    "Don't limit your challenges, challenge your limits! 🚀",
    "The pain you feel today will be the strength you feel tomorrow! 💪"
  ];

  useEffect(() => {
    // Load existing goals
    const savedGoals = localStorage.getItem('gymmy_goals');
    if (savedGoals) {
      setGoals(JSON.parse(savedGoals));
    }

    // Load user data
    const formData = localStorage.getItem('userData');
    if (formData) {
      setUserData(JSON.parse(formData));
    }

    // Set initial quote
    setCurrentQuote(motivationalQuotes[0]);

    // Check if a new goal should be created from form submission
    const shouldCreateGoal = localStorage.getItem('create_new_goal');
    
    if (shouldCreateGoal === 'true' && formData) {
      createGoalFromForm(JSON.parse(formData));
      localStorage.removeItem('create_new_goal');
    }
  }, []);

  // Rotate quotes every 10 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      const randomQuote = motivationalQuotes[Math.floor(Math.random() * motivationalQuotes.length)];
      setCurrentQuote(randomQuote);
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  const createGoalFromForm = (formData: any) => {
    const existingGoals = JSON.parse(localStorage.getItem('gymmy_goals') || '[]');
    const goalNumber = existingGoals.length + 1;
    
    // Map form fitness goal to our goal type
    const goalTypeMapping: { [key: string]: Goal['type'] } = {
      'weight-loss': 'weight-loss',
      'muscle-gain': 'muscle-gain',
      'general-fitness': 'general-fitness',
      'strength-training': 'muscle-gain',
      'endurance': 'endurance',
      'flexibility': 'flexibility'
    };

    // Get target value and unit based on goal type
    let targetValue = 10;
    let unit = 'kg';
    
    if (formData.fitnessGoal === 'weight-loss') {
      targetValue = Math.max(5, Math.floor(parseInt(formData.weight) * 0.1));
      unit = 'kg';
    } else if (formData.fitnessGoal === 'muscle-gain') {
      targetValue = Math.max(2, Math.floor(parseInt(formData.weight) * 0.05));
      unit = 'kg';
    } else if (formData.fitnessGoal === 'endurance') {
      targetValue = 30;
      unit = 'mins';
    } else if (formData.fitnessGoal === 'flexibility') {
      targetValue = parseInt(formData.targetDays) || 10;
      unit = 'days';
    } else {
      targetValue = parseInt(formData.targetDays) || 15;
      unit = 'days';
    }

    const newGoal: Goal = {
      id: Date.now().toString(),
      title: `Goal ${goalNumber}`,
      type: goalTypeMapping[formData.fitnessGoal] || 'general-fitness',
      targetValue: targetValue,
      currentValue: 0,
      unit: unit,
      deadline: new Date(Date.now() + (parseInt(formData.targetDays) * 24 * 60 * 60 * 1000)),
      createdAt: new Date(),
      isCompleted: false,
      points: getPointsForGoalType(goalTypeMapping[formData.fitnessGoal] || 'general-fitness'),
    };

    const updatedGoals = [newGoal, ...existingGoals];
    setGoals(updatedGoals);
    localStorage.setItem('gymmy_goals', JSON.stringify(updatedGoals));
  };

  const handleCreateGoal = (e: React.FormEvent) => {
    e.preventDefault();
    
    const goal: Goal = {
      id: Date.now().toString(),
      title: newGoal.title,
      type: newGoal.type,
      targetValue: parseFloat(newGoal.targetValue),
      currentValue: 0,
      unit: newGoal.unit,
      deadline: new Date(newGoal.deadline),
      createdAt: new Date(),
      isCompleted: false,
      points: getPointsForGoalType(newGoal.type),
    };

    const updatedGoals = [goal, ...goals];
    setGoals(updatedGoals);
    localStorage.setItem('gymmy_goals', JSON.stringify(updatedGoals));
    
    // Reset form
    setNewGoal({
      title: '',
      type: 'weight-loss',
      targetValue: '',
      unit: 'kg',
      deadline: '',
    });
    setShowNewGoalModal(false);
  };

  const getPointsForGoalType = (type: Goal['type']): number => {
    const pointsMap = {
      'weight-loss': 100,
      'muscle-gain': 120,
      'endurance': 90,
      'flexibility': 80,
      'general-fitness': 85,
    };
    return pointsMap[type];
  };

  const getGoalTypeLabel = (type: Goal['type']): string => {
    const labels = {
      'weight-loss': 'Weight Loss',
      'muscle-gain': 'Muscle Gain',
      'endurance': 'Endurance',
      'flexibility': 'Flexibility',
      'general-fitness': 'General Fitness',
    };
    return labels[type];
  };

  const getProgressPercentage = (goal: Goal): number => {
    if (goal.targetValue === 0) return 0;
    return Math.min((goal.currentValue / goal.targetValue) * 100, 100);
  };

  const getDaysRemaining = (deadline: Date): number => {
    const today = new Date();
    const timeDiff = deadline.getTime() - today.getTime();
    return Math.ceil(timeDiff / (1000 * 3600 * 24));
  };

  const handleGoalClick = (goal: Goal) => {
    if (userData) {

      localStorage.getItem('FitnessPlanList')
      const route = `/fitness/}`;
      router.push(route);
    }
  };

  const handleCreateNewGoalClick = () => {
    router.push('/form');
  };

  // Calculate statistics
  const totalGoals = goals.length;
  const completedGoals = goals.filter(g => g.currentValue >= g.targetValue).length;
  const avgProgress = totalGoals > 0 ? 
    goals.reduce((sum, g) => sum + (g.currentValue / g.targetValue * 100), 0) / totalGoals : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 relative overflow-x-hidden">
      {/* Background Gym Icons */}
      <div className="fixed inset-0 pointer-events-none z-0 opacity-5">
        <div className="absolute top-[10%] left-[5%] text-[120px] text-blue-500 animate-bounce" style={{ animationDelay: '0s', animationDuration: '6s' }}>🏋️</div>
        <div className="absolute top-[60%] right-[8%] text-[120px] text-blue-500 animate-pulse" style={{ animationDelay: '2s', animationDuration: '6s' }}>💪</div>
        <div className="absolute bottom-[20%] left-[15%] text-[120px] text-blue-500 animate-bounce" style={{ animationDelay: '4s', animationDuration: '6s' }}>🏃</div>
        <div className="absolute top-[30%] right-[25%] text-[120px] text-blue-500 animate-pulse" style={{ animationDelay: '1s', animationDuration: '6s' }}>🚴</div>
      </div>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto p-8 relative z-10">
        {/* Welcome Section */}
        <section className="text-center mb-12">
          <h1 className="text-5xl font-bold bg-gradient-to-r from-gray-800 to-blue-500 bg-clip-text text-transparent mb-4" style={{ fontFamily: 'Comic Neue, cursive' }}>
            Your Fitness Journey Awaits! 🚀
          </h1>
          <div className="text-xl text-gray-600 italic mb-8 p-4 bg-white/60 rounded-2xl backdrop-blur-lg">
            {currentQuote}
          </div>
          <button
            onClick={handleCreateNewGoalClick}
            className="bg-gradient-to-r from-blue-500 to-purple-500 text-white px-8 py-4 rounded-2xl text-xl font-semibold hover:scale-105 hover:shadow-xl transition-all duration-300 shadow-lg shadow-blue-500/30"
          >
            ✨ Create New Goal
          </button>
        </section>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          <div className="bg-white/90 rounded-2xl p-6 text-center shadow-lg hover:-translate-y-2 transition-all duration-300">
            <div className="text-3xl font-bold text-blue-500 mb-2">{totalGoals}</div>
            <div className="text-gray-600 font-medium">Total Goals</div>
          </div>
          <div className="bg-white/90 rounded-2xl p-6 text-center shadow-lg hover:-translate-y-2 transition-all duration-300">
            <div className="text-3xl font-bold text-green-500 mb-2">{completedGoals}</div>
            <div className="text-gray-600 font-medium">Completed</div>
          </div>
          <div className="bg-white/90 rounded-2xl p-6 text-center shadow-lg hover:-translate-y-2 transition-all duration-300">
            <div className="text-3xl font-bold text-purple-500 mb-2">{avgProgress.toFixed(1)}%</div>
            <div className="text-gray-600 font-medium">Avg Progress</div>
          </div>
        </div>

        {/* Goals Section */}
        <section className="bg-white/80 backdrop-blur-lg rounded-3xl p-8 shadow-xl border border-white/20 mb-8">
          <h2 className="text-3xl font-bold text-gray-800 mb-6 flex items-center gap-2">
            🎯 My Fitness Goals
          </h2>
          
          {goals.length === 0 ? (
            <div className="text-center py-16">
              <div className="text-8xl mb-6">🎯</div>
              <h3 className="text-3xl font-bold text-gray-700 mb-4">No Goals Yet!</h3>
              <p className="text-xl text-gray-600 mb-8">
                Create your first goal to start your amazing fitness journey!
              </p>
              <button
                onClick={handleCreateNewGoalClick}
                className="bg-gradient-to-r from-blue-500 to-purple-500 text-white px-8 py-4 rounded-2xl text-xl font-semibold hover:scale-105 hover:shadow-xl transition-all duration-300 shadow-lg shadow-blue-500/30"
              >
                🚀 Start Your Journey
              </button>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {goals.map((goal) => {
                const progress = getProgressPercentage(goal);
                const daysRemaining = getDaysRemaining(new Date(goal.deadline));
                
                return (
                  <div
                    key={goal.id}
                    onClick={() => handleGoalClick(goal)}
                    className="bg-gradient-to-r from-slate-50 to-slate-100 rounded-2xl p-6 border-l-4 border-blue-500 hover:translate-x-2 hover:shadow-lg hover:shadow-blue-500/15 transition-all duration-300 cursor-pointer hover:scale-105"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <FitnessIcon type={goal.type} className="w-16 h-16" />
                      <div className="text-right">
                        <div className="text-2xl font-bold text-blue-500">+{goal.points}</div>
                        <div className="text-gray-600 text-sm">points</div>
                      </div>
                    </div>
                    
                    <h3 className="text-xl font-bold text-gray-800 mb-2">{goal.title}</h3>
                    <p className="text-blue-600 font-medium mb-4">{getGoalTypeLabel(goal.type)}</p>
                    
                    {/* Progress Bar */}
                    <div className="mb-4">
                      <div className="flex justify-between text-gray-700 text-sm mb-2">
                        <span>{goal.currentValue} / {goal.targetValue} {goal.unit}</span>
                        <span>{progress.toFixed(1)}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-blue-500 to-purple-500 rounded-full transition-all duration-500"
                          style={{ width: `${progress}%` }}
                        ></div>
                      </div>
                    </div>
                    
                    {/* Deadline */}
                    <div className="flex items-center justify-between text-gray-600 text-sm">
                      <span>
                        {daysRemaining > 0
                          ? `${daysRemaining} days left`
                          : 'Overdue'}
                      </span>
                      <span>{goal.isCompleted ? '✅ Completed' : '🎯 In Progress'}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </main>

      {/* Manual Goal Creation Modal */}
      {showNewGoalModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-8 w-full max-w-md shadow-2xl relative">
            <button
              onClick={() => setShowNewGoalModal(false)}
              className="absolute top-4 right-4 text-gray-500 hover:text-gray-700 text-2xl"
            >
              ×
            </button>
            <h3 className="text-2xl font-bold mb-6 text-gray-800">Create New Goal 🎯</h3>

            <form onSubmit={handleCreateGoal} className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Goal Title</label>
                <input
                  type="text"
                  value={newGoal.title}
                  onChange={(e) => setNewGoal({ ...newGoal, title: e.target.value })}
                  className="w-full p-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors"
                  placeholder="e.g., Lose 10kg in 3 months"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Goal Type</label>
                <select
                  value={newGoal.type}
                  onChange={(e) => setNewGoal({ ...newGoal, type: e.target.value as Goal['type'] })}
                  className="w-full p-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors"
                >
                  <option value="weight-loss">Weight Loss 🏃</option>
                  <option value="muscle-gain">Muscle Gain 💪</option>
                  <option value="endurance">Endurance 🚴</option>
                  <option value="flexibility">Flexibility 🧘</option>
                  <option value="general-fitness">General Fitness 🏋️</option>
                </select>
              </div>

              <div className="flex space-x-4">
                <div className="flex-1">
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Target Value</label>
                  <input
                    type="number"
                    value={newGoal.targetValue}
                    onChange={(e) => setNewGoal({ ...newGoal, targetValue: e.target.value })}
                    className="w-full p-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors"
                    placeholder="10"
                    required
                  />
                </div>
                <div className="w-24">
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Unit</label>
                  <select
                    value={newGoal.unit}
                    onChange={(e) => setNewGoal({ ...newGoal, unit: e.target.value })}
                    className="w-full p-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors"
                  >
                    <option value="kg">kg</option>
                    <option value="lbs">lbs</option>
                    <option value="mins">mins</option>
                    <option value="reps">reps</option>
                    <option value="days">days</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Deadline</label>
                <input
                  type="date"
                  value={newGoal.deadline}
                  onChange={(e) => setNewGoal({ ...newGoal, deadline: e.target.value })}
                  className="w-full p-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors"
                  required
                />
              </div>

              <div className="flex gap-4 justify-end">
                <button
                  type="button"
                  onClick={() => setShowNewGoalModal(false)}
                  className="px-6 py-3 bg-gray-500 text-white rounded-xl font-semibold hover:bg-gray-600 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-xl font-semibold hover:scale-105 transition-all duration-300"
                >
                  Create Goal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}