// export interface User {
//   id: string;
//   email: string;
//   name: string;
//   avatar?: string;
//   metrics?: UserMetrics;
//   totalPoints: number;
//   level: number;
//   joinedAt: Date;
// }

// export interface AuthState {
//   user: User | null;
//   isAuthenticated: boolean;
//   isLoading: boolean;
// }
