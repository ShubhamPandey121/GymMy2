// Optional part filled automatically
console.log('Optional logic implemented');